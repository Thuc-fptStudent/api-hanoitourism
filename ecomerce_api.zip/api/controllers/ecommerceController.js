const ecommerceService = require('../Services/ecommerceService');
const { validationResult } = require('express-validator');
const messageConstants = require('../constant/messageConstants');
const Paginator = require('../commons/paginator');

//Get all
exports.getAll = (req,res) => {
    ecommerceService.getAll().then(data=> {
        res.status(200).json({
            success: true,
            message: messageConstants.ECOMMERCE_NOT_FOUND,
            data : data
        });
    }).catch(err => {
        res.send({
            error: {
                status: err.status ||500,
                message: err.message
            }
        })
    });
};

//create
exports.create = (req, res, next) => {
    try {
        const errors = validationResult(req);
        if(!errors.isEmpty()){
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const ecommerce = {
            Name: req.body.Name,
            Description: req.body.Description,
            ImageUrl: req.body.ImageUrl,
            Address: req.body.Address,
            Phone: req.body.Phone,
            Email: req.body.Email,
            CreatedBy: req.body.CreatedBy,
            Status: 1,
            Deleted: 0
        }
        ecommerceService.create(ecommerce).then(result => {
            res.status(200).json({
                success: true,
                message: messageConstants.ECOMMERCE_CREATE_SUSSCESS,
                ecommerce: result
            });
        }).catch(err => {
            res.send({
                error: {
                    status: err.status ||500,
                    message: err.message
                }
            })
        });
    } catch (err) {
        return next(err);
    }
}

//get all paging
exports.getallpaging = async (req,res) => {
    const page = parseInt(req.query.page) ||1;
    const size = parseInt(req.query.size);
    var condition = JSON.stringify(req.query) ||null;
    const { limit, offset } = Paginator.getPagination(page, size);
    const data = { limit, offset, condition };
    await ecommerceService.getallpaging(data).then(data => {
        const reponse = Paginator.getPagingData(data, page, limit);
        res.status(200).json({
            success: true,
            message: messageConstants.ECOMMERCE_NOT_FOUND,
            data: reponse
        });
    }).catch(err => {
        res.send({
            error: {
                status: err.status ||500,
                message: err.message
            }
        })
    });
};

//getbyid
exports.getById = (req, res) => {
    ecommerceService.getById(req.params.id).then(ecommerce => {
        if(ecommerce === null){
            res.status(200).json({
                message: messageConstants.ECOMMERCE_FOUND
            })
        }else{
            res.status(200).json({
                success: true,
                message: messageConstants.ECOMMERCE_NOT_FOUND,
                ecommerce: ecommerce
            });
        }
    }).catch(err => {
        res.send({
            error: {
                status: err.status ||500,
                message: err.message
            }
        })
    });
};

//update
exports.update = (req, res,next) => {
    try {
        const errors = validationResult(req);
        if(!errors.isEmpty()){
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const Id = req.params.id;
        const ecommerceUpdate = {
            Name: req.body.Name,
            Description: req.body.Description,
            ImageUrl: req.body.ImageUrl,
            Address: req.body.Address,
            Phone: req.body.Phone,
            Email: req.body.Email,
            UpdatedBy: req.body.UpdatedBy,
            UpdatedDate: Date()
        };
        ecommerceService.update(Id, ecommerceUpdate).then((result) => {
            if(result == 1){
                res.status(200).json({
                    success: true,
                    message: messageConstants.ECOMMERCE_UPDATE_SUSSCESS
                });
            }else{
                res.status(200).json({
                    message: result.message
                });
            }
        }).catch((err) => {
            res.send({
                error: {
                    status: err.status ||500,
                    message: err.message
                }
            });
        });
    } catch (err) {
        return next(err);
    }
};

//delete
exports.destroy = (req,res) => {
   const Id = req.params.id;
   ecommerceService.destroy(Id).then((result) => {
       if(result == true){
           res.status(200).json({
               success: true,
               result: result,
               message: messageConstants.ECOMMERCE_DELETED
           });
       }else{
           res.status(400).json({
               message: result.message
           });
       }
   }).catch((err) => {
       res.send({
           status: err.status ||500,
           message: err.message
       });
   });
};

//soft delete
exports.delete = (req, res) => {
    const Id = req.params.id;
    const options = { field: "Deleted", Deleted: 1, UpdatedDate: Date() };
    ecommerceService.delete(Id, options).then((result) => {
        if(result == true){
            res.status(200).json({
                success: true,
                message: messageConstants.ECOMMERCE_DELETED
            });
        }else{
            res.status(500).json({
                message: result.message
            });
        }
    }).catch((err) => {
        res.send({
            error: {
                status: err.status ||500,
                message: err.message
            }
        });
    });
};

//restore
exports.restore = (req, res)=> {
    const Id = req.params.id;
    const options = { field: "Deleted", Deleted: 0, UpdatedDate: Date() };
    ecommerceService.restore(Id, options).then((result) => {
        if(result == true){
            res.status(200).json({
                success: true,
                message: messageConstants.ECOMMERCE_RESTORE_SUSSCESS
            });
        }else{
            res.status(500).json({
                message: result.message
            });
        }
    }).catch((err) => {
        res.send({
            error: {
                status: err.status ||500,
                message: err.message
            }
        });
    });
}