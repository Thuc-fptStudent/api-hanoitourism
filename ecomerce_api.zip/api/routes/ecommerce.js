const express = require('express');
const router = express.Router();
const ecommerceController = require('../controllers/ecommerceController');
const { validate } = require('../middlewares/validators');

router.get('/', ecommerceController.getAll);
router.get('/all-paging', ecommerceController.getallpaging);
router.get('/:id', ecommerceController.getById);
router.post('/', validate.validateEcommerce(), ecommerceController.create);
router.put('/:id', validate.validateEcommerce(), ecommerceController.update);
router.delete('/delete/:id', ecommerceController.destroy);
router.delete('/:id', ecommerceController.delete);
router.get('/restore/:id', ecommerceController.restore);

module.exports = router;